This the PHP style suite (PolyStyle, see http://polystyle.com) used to format the code of the structWSFand conStruct projects. The file example.php-code defines the coding standards for these projects. Additionally we have these additional requirements:

- Indent character: space
- Tab width: 2
- Max blank lines: 2
- Encoding: UTF-8
- New line: Unix
- Page width: 120
- Keep HTML cases
