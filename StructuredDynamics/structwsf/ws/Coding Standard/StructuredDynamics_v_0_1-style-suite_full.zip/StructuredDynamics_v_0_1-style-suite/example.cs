/**
 * This is a recommended Polystyle C# example.
 * Reformat this file as you like to define your personal style.
 *
 * Notes:
 * 1.) Polystyle only modifies whitespace and will never alter the actual content
 *     of your files, such as adding {}'s in 'if' statements.
 *
 * 2.) Polystyle does not format comments based on examples. It will always
 *     format comments the same way.
 *
 * Copyright 2001-2003 Flashbulb Studios.
 *
 * http://polystyle.com
 */

using System;
using Diag = System.Diagnostics;
using System.EnterpriseServices;

sealed public internal class Example : Sclass
{
  public ~Example(int a, out int b, int [,,,] c) : base(0)
  {
    // if statements with empty braces
    if (x)
    {
    }
    else if (x)
    {
    }
    else
    {
    }

    // if statements with exactly one braced statement
    if (x)
    {
      a();
    }
    else if (x)
    {
      b();
    }
    else
    {
      c();
    }

    // special 'if' cases
    if (x)
    {
      a();
    }
    else
    {
      c();
    }

    if (x)
    {
      a();

      a();
    }
    else
    {
      c();

      c();
    }

    // if statements with a single implicit substatement
    if (x)
      a();

    else if (x)
      b();

    else
      c();

    // if statements with multiple statements
    if (!z)
    {
      j = ++i & (i());

      z = j[0][0][0];
    }
    else if (a is Class)
    {
      a();

      return method(new String[] { a, b, c }, ref b, 'c');
    }
    else
    {
      a();
    }

    // while statements with a single implicit substatement
    while (x && y)
      new a();

    // while statements with a single implicit 'if' substatement
    while (x)
      if (x)
        a();

    // while with multiple statements
    while (k == &j)
    {
      label:

      h[0] = @a ? ***b : ((int [])c).d->e;

      break;
    }

    // for statements with a single braced statement
    for (int [,] i = { 1, 2, 3 }; i > 6; i++)
    {
      break label;
    }

    foreach (int i in S)
    {
      i >> 1;
    }

    // do statements with a single braced substatement
    do
    {
      continue label;
    } while (false);

    // local blocks
    {
      a();
    }

    // various blocked code
    using (int ***x)
    {
      unsafe
      {
        a();
      }
    }

    fixed (int a)
      a();

    /* Switch blocks:
     *
     * You can have case substatements be aligned by giving an example like:
     *
     * case 1: a();
     * 
     *         b();
     * 
     *         c();
     * 
     *         etc...
     */
    switch (c)
    {
      case 1:
      case 2:
      case 3:
        a();

        b();

        c();

      case 4:
        goto default; // case with exactly one substatement

      default:
        break;
    }
  }

  public void method()
  {
    // try-catch-finally with empty bodies
    try
    {
    }
    catch (Throwable e)
    {
    }
    finally
    {
    }

    // try-catch-finally with exactly one statement
    try
    {
      a();
    }
    catch (Throwable t)
    {
      a();
    }
    finally
    {
      a();
    }

    // try-catch-finally with multiple statements 
    try
    {
      for (;;)
      {
      } // for statement with empty control statements

      a();
    }
    catch (Throwable e)
    {
      do
      {
      } while (x);

      throw e;
    }
    finally
    {
      int i = i * 3, j, k;

      return i + "0";
    }
  }
}

private class Class2
{
  // array with multiple elements
  protected boolean bools1 [][][] =
  {
    false,
    false,
    false
  };

  // array with a single element
  boolean bools2 [] = { false };

  // array with no elements
  boolean bools3 [] = { };

  // multidimensional array
  private const int [][][] array = new int[1][][][]
  {
    { 1, 2, 3 },
    { 1, 2, 3 },
    { 1, 2, 3 },
  };

  abstract Object method1();

  public event int Event
  {
    [a]
    add { }
  }
}

namespace N
{
  public struct S
  {
    static int operator + (int i, int y);
  };
}

delegate int myDelegate();

[a]
[b]
[field : attrib(i, x = 0)]
public enum Enum : int
{
  a = 0,

  [x]
  b = 1,
  c = 2,
};

protected interface Intf : Super, Super2
{
  public void emptyMethod() { }

  [a]
  int prop
  {
    get;
    set;
  }

  // property with exactly one accessor
  int this [int i] { get; }
}

#region satori

  #if (a && !b)

    #warning Thank you for entering the self destruct sequence

  #elif a == true

    #warning a == true

  #else

    #warning warning

  #endif

  #warning warning

  #warning warning

#endregion