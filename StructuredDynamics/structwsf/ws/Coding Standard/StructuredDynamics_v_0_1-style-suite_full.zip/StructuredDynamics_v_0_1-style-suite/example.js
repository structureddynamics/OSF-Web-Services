/**
 * This is a recommended Polystyle Javascript example.
 * Reformat this file as you like to define your personal style.
 *
 * Notes:
 * 1.) Polystyle only modifies whitespace and will never alter the actual content
 *     of your files, such as adding {}'s in 'if' statements.
 *
 * 2.) Polystyle does not format comments based on examples. It will always
 *     format comments the same way.
 *
 * Copyright 2001-2003 Flashbulb Studios.
 *
 * http://polystyle.com
 */

<!--

function funct(a, b, c)
{
  // if statements with empty braces
  if (x)
  {
  }
  else if (x)
  {
  }
  else
  {
  }

  // if statements with exactly one braced statement
  if (x)
  {
    a();
  }
  else if (x)
  {
    b();
  }
  else
  {
    c();
  }

  // if statements with a single implicit substatement
  if (x)
    a();
  else if (x)
    b();
  else
    c();

  // special 'if' cases
  if (x)
  {
    a();
  }
  else
  {
    c();
  }

  if (x)
  {
    a();

    a();
  }
  else
  {
    c();

    c();
  }

  // if statements with multiple statements
  if (!z)
  {
    j = ++i & ((i()));

    z = j[0][0][0];
  }
  else if (a instanceof Class)
  {
    a();

    return typeof x.y;
  }
  else
  {
    a();

    return new Object().method(a, b, c);
  }

  // while statements with a single implicit substatement
  while (x)
    a();

  // while statements with a single implicit 'if' substatement
  while (x)
    if (x)
      a();

  // while with multiple statements
  while (k == j)
  {
    label:

    h[0] = a ? b : c;

    break;
  }

  // for statements with a single braced statement
  for (var i; i > 6; i++)
  {
    break label;
  }

  // for statement with list initialiser and a single multiline substatement
  for (x = 0, i = 0; x < i; x++)
  {
    for (x in set)
      {
      } // for statement with 'in' initialiser  
  }

  for (;;)
  {
  }     // for statement with empty control statements

  // do statements with a single braced substatement
  do
  {
    continue label;
  } while (false);

  do
  {
  } while (x);

  // local blocks
  {
    a();
  }

  /* Switch blocks:
   *
   * You can have case substatements be aligned by giving an example like:
   *
   * case 1: a();
   * 
   *         b();
   * 
   *         c();
   * 
   *         etc...
   */
  switch (c)
  {
    case 1:
    case 2:
    case 3:
      a();

      b();

      c();

    case 4:
      break; // case with exactly one substatement

    default:
      break;
  }

  return 'i' + "0";
}

function noArgFunct()
{
  with (x)
  {
    var i = i * 3, j, k;

    i = [0];
  }

  i >> 1;

  var i = j || k;

  var x = { a: b, c: d, e: f };

  // try-catch-finally with empty bodies
  try
  {
  }
  catch (e)
  {
  }
  finally
  {
  }

  // try-catch-finally with exactly one statement
  try
  {
    a();
  }
  catch (t)
  {
    a();
  }
  finally
  {
    a();
  }

  // try-catch-finally with multiple statements 
  try
  {
    a();

    a();
  }
  catch (e)
  {
    a();

    a();
  }
  finally
  {
    a();

    a();
  }
};

var dim1array = [1, 2, 3];

var dim2array =
[
  [1, 2, 3],
  [1, 2, 3],
  [1, 2, 3]
];

-->