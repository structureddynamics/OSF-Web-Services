#*
#* This is a recommended Polystyle Perl example.
#* Reformat this file as you like to define your personal style. This means
#* changing the whitespace padding between tokens, placement of newlines, and
#* the indents to match your style.
#*
#* You may add snippets of code to this file to elaborate on your style,
#* but it is recommended that you not remove code.
#* 
#* Polystyle ignores the placement of comments in the example file.
#* 
#* To set things such as your page width and indent character, use the 
#* Configuration Tool that comes with Polystyle.
#* 
#* ---
#* 
#* Copyright 2001-2003 Flashbulb Studios.
#*
#* http://Polystyle.com
#*

# If statements with empty braces
if( !$x )
{
}
elsif( $x )
{
}
else
{
}

# If statements with exactly one braced statement
if( $x )
{
  $a;
}
elsif( $x )
{
  $b;
}
else
{
  $c;
}

# Special 'if' cases
if( $x )
{
  $a;
}
else
{
  $c;
}

if( $x )
{
  $a;

  $a;
}
else
{
  $c;

  $c;
}

# If statements with multiple statements
if( $z )
{
  $a;
  
  $a;
  
  $a;
}
elsif( $a )
{
  $a;

  $a;
}
else
{
  $a;

  $a;
}

# While with multiple statements
while( $a )
{
  $a;

  $a;

  $a;
}

# For statements with a single braced statement
for( $i = 0; $i > 6; $i++ )
{
  $a;
}

# For statement with empty control statements with a single multiline statement
# as the body
for( ;; )
{
  # Alternate for statement syntax, and an empty body
  for my $x( $a ) { }
}

# Do statements with a single braced substatement
do
{
  $x;
} while( $false );

do
{
} while( $x );

# empty method 
sub emptyMethod: name()
{
}

# method with one statement
sub method
{
  $a;
}

# method with multiple statements
BEGIN
{
  $a;
  
  $a;
  
  $a;
}

# Subroutine in an expression with no statements
print sub { };

# Subroutine in an expression with one statement
print sub { $x; }

# Subroutine in an expression with multiple statements
print sub
{
  $x;
  
  $x;
  
  $x;
};

# Labeled statement
label:
use a;

# Ternary operator
$a ? $b : $d;

# Method invocation with empty params, also use of new operator
new Object();

# Method invocation with params
&init( $a );

# Various operators and punctuation
my int $i = $a, $j, $k;

$done and not -d ++$i & ($i);

$opt ||= $a / $i || die -&p . $a ? \$b : 'a' x $a if $a * $a - $a..&a;

$i /= $h->$g::$r && $i[0][0][0] >> $i < $i eq $i + $a or () == $j[0];

# Empty hash 
myFunc %{} a;

# Hash with one element
myFunc %{ 0 } a;

# Hash with multiple elements
myFunc
%{
  0 => a,
  1,
  2
} a;

# Special cases
myFunc { 0 }{ 0 }{ 0 } a;

myFunc
{
  0,
  1,
  2
} a;

# Block in an expression with one line
eval { $a };
    
# Block in an expression with multiple lines
eval
{
  $a;
  $a;
  $a
};

# Format statement
format fmt = 
line
line
.

# Use of here docs. This needs to be the last thing in the example file.
print STDERR <<"TO_END";
  text
TO_END

