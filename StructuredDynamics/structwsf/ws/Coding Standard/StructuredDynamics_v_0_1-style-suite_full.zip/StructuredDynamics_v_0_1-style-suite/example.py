#*
#* This is a recommended Polystyle Python example.
#* Reformat this file as you like to define your personal style.
#*
#* Notes:
#* 1.) If you customize this file, add and remove whitespace but do not add or
#*     remove code segments.
#*
#* 2.) Polystyle does not format comments based on examples. It will always
#*     format comments the same way.
#*
#* Copyright 2001-2003 Flashbulb Studios.
#*
#* http:#polystyle.com
#*

import a.b.c
from a import b as c, e as f, g as h
from consts import a, b

global a, b, c

x += j || k, y

assert [x for a for b if c if d](**y) < 6

del x

pass

print >> not x and !y

yield

[] = x

[a] = x[...]

[ a,
  b,
  c ] = x[a:b:c]

x = {}

x = { a: x }

x = {
  a: x,
  b: y,
  c: z
  }

x = ()

w = (x)

y = (x, y, x)

continue

exec a in x, y

class Example (A, B, C):
  def myMethod (a = 0, (x, y, z), as):
    if x: x()
  
    if !z:
      j = ++i & (i is not x)

    elif a:
      raise x

    elif b:
      field.method ((x), b, 'c')

    elif c:
      z=j[0][0][]

    else:
      return field.method()

    while k == j:
      h[0] += c--
      
      lambda x, y, z: a[][][]

    for x[] in y:
      break

    try:
      for x in y: pass; pass;

    except e, t:
      i >> 1
  
    try:
      raise e

    finally:
      i = i * 3, j, k

      return i + "0"
