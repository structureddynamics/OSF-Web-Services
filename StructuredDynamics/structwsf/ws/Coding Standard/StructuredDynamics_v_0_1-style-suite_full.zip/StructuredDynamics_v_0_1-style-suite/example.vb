VERSION 1.0 CLASS BEGIN
    statement
END

x & x

x And x

a.x

x * x

x + x

x = x

x || x

x <= x

x ? x : x

x, x

x (x) x

x [x] x

x {x} x

<x> Public Class X
    Inherits Y
    statement

    statement

    statement
End Class

Try
    statement
Finally
    statement
End Try

Select Case s
    Case c
        statement
End Select

Do
    While x
        statement
    Wend
Loop Until x

For x
    statement

    statement

    statement
Next x

Declare X Sub Y

Public Event X Sub Y Inherits I

If x Then
    statement
ElseIf y
    statement
Else
    statement
End If

#Region x
    statement
#End Region

#If x Then
    statement
#ElseIf x Then
    statement
#Else
    statement
#End If
